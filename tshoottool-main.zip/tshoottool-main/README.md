# Customer Modem Light Tool
Allows technicians to effortlessly input customer modem make/model and internet light statuses
